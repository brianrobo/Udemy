package com.brian.firstvertx;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;

/**
 * Hello world!
 *
 */
public class App extends AbstractVerticle {
	private static final Logger LOGGER = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) {
		Vertx vertx = Vertx.vertx();
		vertx.deployVerticle(new App());
	}

	@Override
	public void start() throws Exception {
		LOGGER.info("Verticle App Started");
	}

	@Override
	public void stop() throws Exception {
		LOGGER.info("Verticle App Stopped");
	}
}
