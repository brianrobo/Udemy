package com.brian.formalapi;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.brian.formalapi.entity.Product;

import io.vertx.config.ConfigRetriever;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Vertx;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonObject;
import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.ext.web.handler.StaticHandler;

public class FormalAPIVerticle extends AbstractVerticle {

	private static final Logger LOGGER = LoggerFactory.getLogger(FormalAPIVerticle.class);

	public static void main(String[] args) {

		// DeploymentOptions options = new DeploymentOptions();
		// options.setConfig(new JsonObject().put("http.port", 8080));

		Vertx vertx = Vertx.vertx();

		// Use config/config.json from resources/classpath
		ConfigRetriever configRetriever = ConfigRetriever.create(vertx);
		configRetriever.getConfig(config -> {
			if (config.succeeded()) {
				JsonObject configJson = config.result();
				// System.out.println(configJson.encodePrettily());
				DeploymentOptions options = new DeploymentOptions().setConfig(configJson);

				vertx.deployVerticle(new FormalAPIVerticle(), options);
			}
		});

		// vertx.deployVerticle(new HelloWorldAPIVerticle());
	}

	@Override
	public void start() {
		LOGGER.info("Verticle FormalAPIVerticle Started");

		Router router = Router.router(vertx);

		// API routing
		router.route("/api/v1/products*").handler(BodyHandler.create()); // (me) This need to take the http put body to convert it to json.
		router.get("/api/v1/products").handler(this::getAllProducts);
		router.get("/api/v1/products/:id").handler(this::getProductById);
		router.post("/api/v1/products/").handler(this::addProduct);
		router.put("/api/v1/products/:id").handler(this::updateProductById);
		router.delete("/api/v1/products/:id").handler(this::deleteProductById);

		// Regarding /yo.html
		router.get("/yo.html").handler(routingContext -> {
			ClassLoader classLoader = getClass().getClassLoader();
			File file = new File(classLoader.getResource("webroot/yo.html").getFile());

			String mappedHTML = "";

			try {
				StringBuilder result = new StringBuilder("");
				Scanner scanner = new Scanner(file);

				while (scanner.hasNextLine()) {
					String line = scanner.nextLine();
					result.append(line).append("\n");
				}

				scanner.close();
				mappedHTML = result.toString();
				mappedHTML = replaceAllTokens(mappedHTML, "{name}", "Tom Jay");
			} catch (IOException e) {
				e.printStackTrace();
			}

			routingContext.response().putHeader("content-type", "text/html").end(mappedHTML);
		});

		// Default handler if no routes are matched
		router.route().handler(StaticHandler.create().setCachingEnabled(false));
		// vertx.createHttpServer().requestHandler(router::accept).listen(8080);
		vertx.createHttpServer().requestHandler(router::accept).listen(config().getInteger("http.port"));
	}

	// Get all products as array of products
	private void getAllProducts(RoutingContext routingContext) {
		JsonObject responseJson = new JsonObject();

		Product firstItem = new Product("112233", "123", "My item 123");
		Product secondItem = new Product("11334455", "321", "My item 321");
		List<Product> products = new ArrayList<Product>();
		products.add(firstItem);
		products.add(secondItem);

		responseJson.put("products", products);

		routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
				.end(Json.encodePrettily(responseJson));
	}

	// Get one products that matches the input id and return as single json object
	private void getProductById(RoutingContext routingContext) {		
		final String productId = routingContext.request().getParam("id");
		
		String number = "123";		
		Product firstItem = new Product(productId, number, "My item " + number);
		
		routingContext.response()
		.setStatusCode(200)
		.putHeader("content-type", "application/json")
		.end(Json.encodePrettily(firstItem));
	}
	
	// Insert one item passed in from the http post body return what was added with unique id from the insert
	private void addProduct(RoutingContext routingContext) {
		
		JsonObject jsonBody = routingContext.getBodyAsJson();		
		System.out.println(jsonBody);
		String number = jsonBody.getString("number");
		String description = jsonBody.getString("description");		
		
		Product newItem = new Product("", number, description);
		
		// Add into database and get unique id
		newItem.setId("556677");
		
		routingContext.response()
		.setStatusCode(201)
		.putHeader("content-type", "application/json")
		.end(Json.encodePrettily(newItem));
	}

	// Update the item based on the url product id and return update product info
	private void updateProductById(RoutingContext routingContext) {
		final String productId = routingContext.request().getParam("id");
		
		JsonObject jsonBody = routingContext.getBodyAsJson();
		String number = jsonBody.getString("number");
		String description = jsonBody.getString("description");
		
		Product updatedItem = new Product(productId, number, description);
		
		routingContext.response()
		.setStatusCode(200)
		.putHeader("content-type", "application/json")
		.end(Json.encodePrettily(updatedItem));
	}
	
	// Delete item and return 200 on success or 400 on fail
	private void deleteProductById(RoutingContext routingContext) {
		final String productId = routingContext.request().getParam("id");
		
		routingContext.response()
		.setStatusCode(200)
		.putHeader("content-type", "application/json")
		.end();
	}

	public String replaceAllTokens(String input, String token, String newValue) {
		String output = input;
		while (output.indexOf(token) != -1) {
			output = output.replace(token, newValue);
		}
		return output;
	}

	@Override
	public void stop() {
		LOGGER.info("Verticle FormalAPIVerticle Stopped");
	}

}
